﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace TestProject
{
    class DetaislModel
    {
        public string DeviceName { get; set; }
        public string TestId { get; set; }
        public string CustomerName { get; set; }
        public string CompanyName { get; set; }
    }
}
