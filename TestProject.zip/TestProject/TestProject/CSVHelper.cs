﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject
{
    public class CSVHelper
    {

        internal IEnumerable<DetaislModel> ReadCSVForDetails(string FolderDetails)
        {
            string[] files = GetFiles(FolderDetails);
            List<DetaislModel> details = new List<DetaislModel>();
            foreach (var fileName in files)
            {
                 string[] lines = File.ReadAllLines(System.IO.Path.ChangeExtension(fileName, ".csv"));

                details.Add(new DetaislModel()
                {
                    DeviceName=lines[0].Split(',')[0],
                    TestId=lines[1].Split(',')[1],
                    CustomerName=lines[2].Split(',')[1],
                    CompanyName=lines[3].Split(',')[1],
                });
            }
            return details;
        }

        private string[] GetFiles(string folderDetails)
        {
            return Directory.GetFiles(folderDetails, "*.csv",
                                         SearchOption.TopDirectoryOnly);
        }
    }
}
